from django.db.models.signals import pre_save, post_save
from django.dispatch import receiver
from django.utils import timezone
from django.db import models
from django.contrib.auth.models import AbstractUser

# class UserModel(models.Model):
#     name = models.CharField(max_length=255)
#     email = models.EmailField(unique=True)
#     phone_no = models.CharField(max_length=20, unique=True)
#
#     class Meta:
#         verbose_name_plural = 'Users'
#
#     def __str__(self):
#         return self.name
#
#
# QUALIFICATION_CHOICES = (
#     ('None', 'None'),
#     ('Professor', 'PHD'),
#     ('Lecturer', 'MPhil'),
#     ('Asc.Lecturer', 'Masters'),
#     ('Lab.Asc', 'Bachelors'),
# )
#
#
# POSITION_CHOICES = (
#     ('None', 'None'),
#     ('Professor', 'Professor'),
#     ('Lecturer', 'Lecturer'),
#     ('Asc.Lecturer', 'Asc.Lecturer'),
#     ('Lab.Asc', 'Lab.Asc'),
# )
#
#
# class StaffModel(UserModel):
#     staff_id = models.CharField(max_length=255, unique=True)
#     joined_date = models.DateField(default=timezone.now)
#     position = models.CharField(max_length=255, choices=POSITION_CHOICES, default='None')
#     # user_qualification = models.ForeignKey(QualificationModel, on_delete=models.CASCADE, null=True)
#     user_qualification = models.CharField(max_length=255, choices=QUALIFICATION_CHOICES, default='None', blank=True)
#     # user_qualification = models.CharField(max_length=255, default='None', null=True)
#     # user_staff = models.ForeignKey(UserModel, on_delete=models.CASCADE)
#
#     def save(self, *args, **kwargs):
#         position = self.position
#         dictt = {
#             'None': 'None',
#             'Professor': 'PHD',
#             'Lecturer': 'MPhil',
#             'Asc.Lecturer': 'Masters',
#             'Lab.Asc': 'Bachelors',
#         }
#         # if position == "abc":
#         self.user_qualification = dictt.get(position)
#         super().save(*args, **kwargs)
#
#     class Meta:
#         verbose_name_plural = 'Staff'
#
#     def __str__(self):
#         return str(self.position)
#
#
# class QualificationModel(StaffModel):
#     # qualification = models.CharField(max_length=255, choices=QUALIFICATION_CHOICES, null=True)
#     university = models.CharField(max_length=255, blank=True)
#     # qualification = models.CharField(max_length=255, blank=True)
#
#     # def save(self, *args, **kwargs):
#     #     position = self.position
#     #     self.qualification = models.CharField(max_length=255, choices=QUALIFICATION_CHOICES, default=position)
#     #     super().save(*args, **kwargs)
#
#     class Meta:
#         verbose_name_plural = 'qualification'
#
#     def __str__(self):
#         return str(self.name)
#


# SECOND MODEL

QUALIFICATION_CHOICES = (
    ('None', 'None'),
    ('PHD', 'PHD'),
    ('MPhil', 'MPhil'),
    ('Masters', 'Masters'),
    ('Bachelors', 'Bachelors'),
)

POSITION_CHOICES = (
    ('None', 'None'),
    ('PHD', 'Professor'),
    ('MPhil', 'Lecturer'),
    ('Masters', 'Asc.Lecturer'),
    ('Bachelors', 'Lab.Asc'),
)


# USER MODEL
class UserModel(models.Model):
    # UNIQUE = name
    name = models.CharField(max_length=255)
    email = models.EmailField(unique=True)
    phone_no = models.CharField(max_length=20, unique=True)

    class Meta:
        verbose_name_plural = 'Users'

    def __str__(self):
        return str(self.name)


class StaffModel(models.Model):
    # UNIQUE = staff_id
    staff_id = models.CharField(max_length=255, unique=True)
    joined_date = models.DateField(default=timezone.now)
    position = models.CharField(max_length=255, default='None', blank=True)
    user_name = models.ForeignKey(UserModel, on_delete=models.CASCADE, blank=True)

    class Meta:
        verbose_name_plural = 'Staff'

    def __str__(self):
        return str(self.staff_id)


class QualificationModel(models.Model):
    # UNIQUE = qualification
    qualification = models.CharField(max_length=255, choices=QUALIFICATION_CHOICES, default='None', blank=True)
    university = models.CharField(max_length=255, blank=True)
    staff_member = models.ForeignKey(StaffModel, on_delete=models.CASCADE, blank=True)

    class Meta:
        verbose_name_plural = 'qualification'

    def __str__(self):
        return str(self.staff_member)


@receiver(post_save, sender=QualificationModel)
def update_position(sender, instance, created, **kwargs):
    quali = instance.qualification
    member = instance.staff_member
    # print(quali)
    # print(member)
    dictt = {
        'None': 'None',
        'PHD': 'Professor',
        'MPhil': 'Lecturer',
        'Masters': 'Asc.Lecturer',
        'Bachelors': 'Lab.Asc',
    }
    pos = dictt.get(quali)
    print(pos)
    stf = StaffModel.objects.get(staff_id=member)
    stf.position = pos
    stf.save()
    # position.save()
    # print(position)
