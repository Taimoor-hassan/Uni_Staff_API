from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import *
from .serializers import *


class StaffAPIView(APIView):
    def get(self, request):
        user = UserModel.objects.all()
        userserializer = UserSerializer(user, many=True)
        staff = StaffModel.objects.all()
        staffserializer = StaffSerializer(staff, many=True)
        qualification = QualificationModel.objects.all()
        qualificationserializer = QualificationSerializer(qualification, many=True)
        return Response({
            'success': True,
            'message': 'Your are shown the request of GET data',
            'user_data': userserializer.data,
            'staff_data': staffserializer.data,
            'qualification_data': qualificationserializer.data,
        })

    def post(self, request):

        if request.data.get('name') != None:
            serializer = UserSerializer(data=request.data)

        if request.data.get('staff_id') != None:
            serializer = StaffSerializer(data=request.data)

        if request.data.get('qualification') != None:
            serializer = QualificationSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response({
                'success': True,
                'message': 'Your Post was successful of below JSON',
                'data': serializer.data,
            }, status=status.HTTP_200_OK)

    def put(self, request):

        if request.data.get('id') != None:
            if request.data.get('name') != None:
                person = UserModel.objects.get(pk=request.data.get('id'))
                serializer = UserSerializer(person, data=request.data)

            if request.data.get('qualification') != None:
                person = QualificationModel.objects.get(pk=request.data.get('id'))
                serializer = QualificationSerializer(person, data=request.data)

            if request.data.get('staff_id') != None:
                person = StaffModel.objects.get(pk=request.data.get('id'))
                serializer = StaffSerializer(person, data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response({
                'success': True,
                'message': 'Your PUT was successful of below JSON',
                'data': serializer.data,
            }, status=status.HTTP_200_OK)

    def delete(self, request):

        if request.data.get('id') != None:
            if request.data.get('name') != None:
                person = UserModel.objects.get(pk=request.data.get('id'))

            if request.data.get('qualification') != None:
                person = QualificationModel.objects.get(pk=request.data.get('id'))

            if request.data.get('staff_id') != None:
                person = StaffModel.objects.get(pk=request.data.get('id'))

        person.delete()
        return Response({
            'success': True,
            'message': 'Deleted successfully',
        }, status=status.HTTP_200_OK)
