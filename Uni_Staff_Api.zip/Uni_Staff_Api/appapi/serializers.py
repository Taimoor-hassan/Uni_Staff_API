from rest_framework import serializers
from .models import *


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserModel
        fields = '__all__'


class StaffSerializer(serializers.ModelSerializer):
    class Meta:
        model = StaffModel
        fields = '__all__'


class QualificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = QualificationModel
        fields = '__all__'
